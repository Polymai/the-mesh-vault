# TheMeshVault Backbone host

This optional Node.js 20+ process keeps signed control records and encrypted shards available without an open browser tab. A local-only process is useful for management and storage-engine testing; it becomes a real internet mesh participant only after it has a public, pinned `wss://` endpoint.

## Start on Windows

The normal flow is **Start Backbone servers** inside TheMeshVault. Choose 1-32 logical servers, then open the downloaded Windows launcher once. It downloads this package, selects safe capacity and a free local port, reuses one physical-host identity for the computer and starts all selected logical instances in one host process.

The Backbone page polls a loopback-only management endpoint to show real per-instance status. It can stop, start or restart one logical instance without stopping the shared host process. The endpoint accepts only the production TheMeshVault origin and localhost development origins; it exposes no Vault ID, Mesh Key, file name or shard bytes.

For a manually downloaded package:

1. Unzip the server package into a permanent folder.
2. Download `backbone-host.json` from the advanced Backbone setup flow.
3. Double-click `Start TheMeshVault Backbone.cmd` in the unzipped folder.

The launcher changes to the correct server folder automatically, finds the newest downloaded configuration (or lets you choose it), installs the one dependency on first start, checks the configuration and starts the process. Do not run the npm commands from your Windows home directory.

## Manual start on Windows or Linux

Run `npm install`, `npm run check` and `npm start` from this directory, which contains `package.json`. Set `MESHVAULT_BACKBONE_CONFIG` if the configuration is stored elsewhere.

For public cold start, terminate TLS here or in a reverse proxy and publish a `wss://` URL. Copy the printed public-key pin into the deployed `data/backboneConfig.js`.

On Windows, run `install-backbone-service.ps1` as Administrator after the checks pass. It installs one hidden SYSTEM startup task with automatic restart. `uninstall-backbone-service.ps1` removes that task. The normal `run-backbone.ps1 -ConfigPath <path>` command remains available for foreground testing.

Each logical instance has its own UUID and quota. Every instance on the same physical host reports the same `failureDomainId`; they therefore count as one independent device. Eight logical servers increase local work queues and advertised capacity, but do not claim eight-device resilience. On Windows the host resolves drive letters to physical disk numbers, so partitions such as `D:` and `E:` on the same disk cannot masquerade as independent devices.

The one-click local launcher does not configure or contact Supabase. It reports zero remotely usable capacity and cannot receive shards from the public site because its management endpoint is bound to its own loopback address. A manually deployed public host may use the frontend-safe Supabase key for one aggregate physical-host registration every ten minutes; its logical storage lanes are never registered as separate devices. Discovery, signed control exchange and shard bytes then use the pinned Backbone WebSocket. No file key, Mesh Key or readable file is sent to this process or Supabase.

Run `npm test` for local tests. The tests do not contact Supabase.
