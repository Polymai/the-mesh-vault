# TheMeshVault Backbone host

This optional Node.js 20+ process keeps signed control records and encrypted shards available without an open browser tab. It is a real mesh participant, not a simulated node.

## Start on Windows

The normal flow is the **Start Backbone server** button inside TheMeshVault. It creates one named Windows launcher. Open that downloaded file once; it downloads this package, selects a safe capacity and free local port, reuses one physical-host identity for the computer and starts the server.

For a manually downloaded package:

1. Unzip the server package into a permanent folder.
2. Download `backbone-host.json` from the advanced Backbone setup flow.
3. Double-click `Start TheMeshVault Backbone.cmd` in the unzipped folder.

The launcher changes to the correct server folder automatically, finds the newest downloaded configuration (or lets you choose it), installs the one dependency on first start, checks the configuration and starts the process. Do not run the npm commands from your Windows home directory.

## Manual start on Windows or Linux

Run `npm install`, `npm run check` and `npm start` from this directory, which contains `package.json`. Set `MESHVAULT_BACKBONE_CONFIG` if the configuration is stored elsewhere.

For public cold start, terminate TLS here or in a reverse proxy and publish a `wss://` URL. Copy the printed public-key pin into the deployed `data/backboneConfig.js`.

On Windows, run `install-backbone-service.ps1` as Administrator after the checks pass. It installs one hidden SYSTEM startup task with automatic restart. `uninstall-backbone-service.ps1` removes that task. The normal `run-backbone.ps1 -ConfigPath <path>` command remains available for foreground testing.

Each logical instance has its own UUID and quota. Every instance on the same physical host reports the same `failureDomainId`; they therefore count as one independent device. On Windows the host resolves drive letters to physical disk numbers, so partitions such as `D:` and `E:` on the same disk cannot masquerade as independent devices.

The public Supabase key in the config is not a secret. It is used for one anonymous compatibility session and a batched node heartbeat (ten minutes by default), because the current placement tables require registered node UUIDs. Discovery, signed control exchange and shard bytes use the Backbone WebSocket. A host without a public `wss://` address reports zero remotely usable storage. No file key, Mesh Key or readable file is sent to this process or Supabase.

Run `npm test` for local tests. The tests do not contact Supabase.
